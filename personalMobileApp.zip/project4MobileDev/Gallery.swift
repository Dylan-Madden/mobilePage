//
//  Gallery.swift
//  project4MobileDev
//
//  Created by Dylan Madden on 2/24/25.
//

import SwiftUI
let galleryGradeient: [Color] = [
    .galleryTop,
    .galleryBottom
]

struct Gallery: View {
    let galleryItems: [GalleryItem] = [
            GalleryItem(title: "Wolf Of Wall Street",subtitle: "My favorite movie"),
            GalleryItem(title: "Breaking Bad",subtitle: "My favorite show"),
            GalleryItem(title: "squatting",subtitle: "My favorite excersise"),
            GalleryItem(title: "BeefEater",subtitle: "My dog")
        ]
    @State private var index: Int = 0
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: galleryGradeient), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            VStack{
                Text(galleryItems[index].title)
                    .font(.title)
                Text(galleryItems[index].subtitle)
                    .font(.title2)
                    .opacity(0.7)
                Image(galleryItems[index].title)
                    .resizable()
                    .scaledToFit()//needed reddit
                    .frame(width: 300, height: 400)
                
                    .padding()
                HStack{
                    Button(action: previousImage) {
                        Text("Previous")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding()
                    Button(action: nextImage) {
                        Text("Next")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding()
                }
                .padding()
            }
        }
        
    }
    private func previousImage() {
           index = (index - 1 + galleryItems.count) % galleryItems.count
       }
    private func nextImage() {
        index = (index + 1) % galleryItems.count
    }
}

#Preview {
    Gallery()
}
