//
//  Profile.swift
//  project4MobileDev
//
//  Created by Dylan Madden on 2/24/25.
//

import SwiftUI

// Define your gradient colors
let gradientColors: [Color] = [
    .profileTop,
    .profileBottom
]

struct Profile: View {
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: gradientColors), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                Text("Dylan Madden")
                    .font(.title)
                    .padding(.top, 20)
                
                Image("appProfilePic")
                    .resizable()
                    .frame(width: 220, height: 300)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.white, lineWidth: 4))
                    .shadow(radius: 10)
                
                Text("Favorite Foods")
                    .font(.title2)
                    .opacity(0.5)
                
                HStack {
                    Image("Steak").resizable().frame(width: 50, height: 50)
                    Image("Pasta").resizable().frame(width: 50, height: 50)
                    Image("Chicken").resizable().frame(width: 75, height: 50)
                }
                .padding()
                
                Text("Favorite Teams")
                    .font(.title2)
                    .opacity(0.5)
                
                HStack {
                    Image("Yankees").resizable().frame(width: 50, height: 50)
                    Image("Sixers").resizable().frame(width: 50, height: 50)
                    Image("Commanders").resizable().frame(width: 75, height: 50)
                }
                .padding()
                
                Text("Favorite Sports")
                    .font(.title2)
                    .opacity(0.5)
                
                HStack {
                    Image("baseball").resizable().frame(width: 50, height: 50)
                    Image("basketball").resizable().frame(width: 50, height: 50)
                    Image("football").resizable().frame(width: 75, height: 50)
                }
                .padding()
            }
        }
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}
