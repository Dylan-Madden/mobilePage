//
//  ContentView.swift
//  project4MobileDev
//
//  Created by Dylan Madden on 2/24/25.
//

import SwiftUI


struct ContentView: View {
    var body: some View {
        TabView {
            Tab("Profile", systemImage: "person"){
                Profile()
            }
            Tab("Gallery", systemImage: "photo.artframe"){
                Gallery()
            }
            Tab("Fun Facts", systemImage: "smiley"){
                FunFacts()
            }
            Tab("My Songs", systemImage: "music.house"){
                MySongs()
            }

        }
        .font(.headline.weight(.bold))
        .accentColor(.black)
        .background(Color.white)
        
        
    }
}

#Preview {
    ContentView()
}
