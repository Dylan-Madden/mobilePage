import SwiftUI

struct MySongs: View {
    @State private var songs: [Song_Type] = [
        Song_Type(title: "Free Bird", artist: "Lynrd Skynrd", isFavorite: true),
        Song_Type(title: "Shape of You", artist: "Ed Sheeran", isFavorite: false),
        Song_Type(title: "Something In the Orange", artist: "Zach Bryan", isFavorite: false),
        Song_Type(title: "Happier", artist: "MarshMello", isFavorite: false)
    ]
    @State private var songToAdd = ""
    
    @State private var disableSubmit:Bool = true
    
    
    var body: some View {
        VStack {
            Text("My Songs View")
                .font(.title)
            NavigationStack {
                List {
                    ForEach(songs, id: \.title) { song in
                        NavigationLink(destination: editSongView(song: song)){
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(song.title)
                                        .font(.title2)
                                    Text(song.artist ?? "")
                                        .font(.title3)
                                        .foregroundColor(.gray)
                                }
                                
                                Spacer()
                                if song.isFavorite {
                                    Image(systemName:"heart.fill")
                                        .foregroundColor(.red)
                                }
                                
                            }
                        }
                        
                    
                    }
                }
            }
        
            HStack {
                TextField("Add Song", text: $songToAdd)
                    .padding()
                    .onChange(of: songToAdd){ newValue in
                        submitButtonActived()
                    }
            
                Button(action: submitSong){
                    Text("Submit")
                        .padding()
                        .opacity(1.3)
                    
                }
                .disabled(disableSubmit)
            }
        }
    }
    private func submitSong(){
        songs.append(Song_Type(title:songToAdd,artist: nil,
                               isFavorite: false))
        songToAdd = ""
    }
    private func submitButtonActived(){
        disableSubmit = songToAdd.count < 2
    }
}

#Preview {
    MySongs()
}
