import SwiftUI
let funFactsGradient: [Color] = [
    .funFactsBottom,
    .funFactsTop
]
struct FunFacts: View {
    @State private var text: String = "Click the Random Button to Generate facts"
    @State private var shownItems: [Int] = []
    @State private var clicked: Int = 0
    @State private var randomFact: [String] = [
        "I have broken all my fingers at different times",
        "I got a 493 on my SHSAT",
        "I went to a Bruno Mars Concert",
        "I found William Dafoe on my stoop"
    ]
    
    private var allFactsShown: Bool {
        return shownItems.count == randomFact.count
    }
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: funFactsGradient), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                Text("Fun Facts About Me")
                    .font(.title)
                
                Text(text)
                    .font(.title)
                    .bold()
                    .opacity(0.5)
                    .frame(height: 300, alignment: .center)
                    .background(Gradient(colors: gradientColors))
                
                Button(action: randomizeFacts) {
                    Text("Generate Random Fact")
                }.background(.white)
                    .clipShape(Rectangle())
                .disabled(allFactsShown)
                
                Button(action: reset) {
                    Text("Reset facts")
                }
                .background(.white)
                .clipShape(Rectangle())
                .disabled(!allFactsShown)
            }
        }
    }
    
    private func randomizeFacts() {
        if allFactsShown {
            text = "No more facts to show!"
            return
        }
        
        var selected = Int.random(in: 0..<randomFact.count)
        while shownItems.contains(selected) {
            selected = Int.random(in: 0..<randomFact.count)
        }
        
        shownItems.append(selected)
        text = randomFact[selected]
        clicked += 1
    }
    
    private func reset() {
        if allFactsShown {
            shownItems = []
        }
        text = "Click the Random Button to Generate facts"
    }
}

#Preview {
    FunFacts()
}
