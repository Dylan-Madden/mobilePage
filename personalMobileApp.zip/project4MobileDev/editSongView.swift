//
//  editSongView.swift
//  project4MobileDev
//
//  Created by Dylan Madden on 3/4/25.
//

import SwiftUI
struct editSongView: View {
    var song : Song_Type
    var body: some View {
        Text(song.title)
    }
}
