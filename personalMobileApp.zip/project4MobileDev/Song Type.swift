//
//  Song Type.swift
//  project4MobileDev
//
//  Created by Dylan Madden on 3/3/25.
//

import SwiftUI

struct Song_Type {
    var title : String
    var artist: String?
    var isFavorite : Bool
}
