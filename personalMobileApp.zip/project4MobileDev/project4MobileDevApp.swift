//
//  project4MobileDevApp.swift
//  project4MobileDev
//
//  Created by Dylan Madden on 2/24/25.
//

import SwiftUI

@main
struct project4MobileDevApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
